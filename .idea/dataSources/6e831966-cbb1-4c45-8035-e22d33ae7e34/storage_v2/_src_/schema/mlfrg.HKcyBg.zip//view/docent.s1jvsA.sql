create view docent as
select distinct `bioinfadmin`.`docent`.`slb_id`         AS `slb_id`,
                `bioinfadmin`.`docent`.`voornaam`       AS `voornaam`,
                `bioinfadmin`.`docent`.`tussenvoegsels` AS `tussenvoegsels`,
                `bioinfadmin`.`docent`.`achternaam`     AS `achternaam`
from `bioinfadmin`.`docent`;

