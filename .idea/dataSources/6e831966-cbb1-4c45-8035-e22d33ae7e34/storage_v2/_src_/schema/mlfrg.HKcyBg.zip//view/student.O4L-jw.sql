create view student as
select `bioinfadmin`.`student`.`student_nr`     AS `student_nr`,
       `bioinfadmin`.`student`.`voornaam`       AS `voornaam`,
       `bioinfadmin`.`student`.`tussenvoegsels` AS `tussenvoegsels`,
       `bioinfadmin`.`student`.`achternaam`     AS `achternaam`,
       `bioinfadmin`.`student`.`geb_datum`      AS `geb_datum`,
       `bioinfadmin`.`student`.`woonplaats`     AS `woonplaats`,
       `bioinfadmin`.`student`.`email`          AS `email`,
       `bioinfadmin`.`student`.`mobiel`         AS `mobiel`,
       `bioinfadmin`.`student`.`klas_id`        AS `klas_id`,
       `bioinfadmin`.`student`.`slb_id`         AS `slb_id`
from `bioinfadmin`.`student`;

